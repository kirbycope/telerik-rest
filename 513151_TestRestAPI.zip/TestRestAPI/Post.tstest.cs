using Telerik.TestingFramework.Controls.KendoUI;
using Telerik.WebAii.Controls.Html;
using Telerik.WebAii.Controls.Xaml;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

using ArtOfTest.Common.UnitTesting;
using ArtOfTest.WebAii.Core;
using ArtOfTest.WebAii.Controls.HtmlControls;
using ArtOfTest.WebAii.Controls.HtmlControls.HtmlAsserts;
using ArtOfTest.WebAii.Design;
using ArtOfTest.WebAii.Design.Execution;
using ArtOfTest.WebAii.ObjectModel;
using ArtOfTest.WebAii.Silverlight;
using ArtOfTest.WebAii.Silverlight.UI;

using System.Net.Http;
using System.Net.Http.Formatting;

namespace TestRestAPI
{
    public class Post : BaseWebAiiTest
    {
        [CodedStep(@"Post")]
        public void Post_CodedStep()
        {
            // Close the web browser window (not needed)
            ActiveBrowser.Close();
            
            // Create the user login data
            String [] user = {"username", "password"};
            
            // Create and define the HttpContent object to be passed in client.PostAsync function
            HttpContent content = new ObjectContent<String[]>(user, new JsonMediaTypeFormatter());
            
            // Write action to console
            Console.WriteLine("Sending POST...");
                
            // Create and define the result of the POST
            HttpResponseMessage result = RestClient.client.PostAsync("post", content).Result;
            
            // Handle HttpClient Result
            if ((int) result.StatusCode == 200)
            {
                // Response was OK
                Console.WriteLine("Response == 'OK'");
                
                // Write result to log
                Log.WriteLine(result.ToString());
            }
            else
            {
                // Response was not expected
                Console.WriteLine("Response != 'OK'");
                throw new Exception(result.ToString());
            }
        }
    }
}
