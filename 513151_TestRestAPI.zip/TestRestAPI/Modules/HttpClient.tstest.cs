using Telerik.TestingFramework.Controls.KendoUI;
using Telerik.WebAii.Controls.Html;
using Telerik.WebAii.Controls.Xaml;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

using ArtOfTest.Common.UnitTesting;
using ArtOfTest.WebAii.Core;
using ArtOfTest.WebAii.Controls.HtmlControls;
using ArtOfTest.WebAii.Controls.HtmlControls.HtmlAsserts;
using ArtOfTest.WebAii.Design;
using ArtOfTest.WebAii.Design.Execution;
using ArtOfTest.WebAii.ObjectModel;
using ArtOfTest.WebAii.Silverlight;
using ArtOfTest.WebAii.Silverlight.UI;

using System.Net.Http;
using System.Net.Http.Formatting;

namespace TestRestAPI
{
    public class RestClient
    {
        private static HttpClient _client = null;

        public static HttpClient client
        {
            get
            {
                if (_client == null)
                {
                    // Write action to console
                    Console.WriteLine("No active HttpClient, creating a new one.");
                    
                    // Create new Http Client Handler
                    HttpClientHandler handler = new HttpClientHandler
                    {
                        // Do not use a proxy
                        UseProxy = false
                    };
                    
                    // Create new Http Client using the Handler
                    _client = new HttpClient(handler);
                    
                    // Set BaseAddress
                    _client.BaseAddress = new Uri("http://httpbin.org/");
                    
                    // Write action to console
                    Console.WriteLine("Set Base Address to " + _client.BaseAddress.ToString());
                }
                return _client;
             }
         }
    }
}
