using Telerik.TestingFramework.Controls.KendoUI;
using Telerik.WebAii.Controls.Html;
using Telerik.WebAii.Controls.Xaml;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

using ArtOfTest.Common.UnitTesting;
using ArtOfTest.WebAii.Core;
using ArtOfTest.WebAii.Controls.HtmlControls;
using ArtOfTest.WebAii.Controls.HtmlControls.HtmlAsserts;
using ArtOfTest.WebAii.Design;
using ArtOfTest.WebAii.Design.Execution;
using ArtOfTest.WebAii.ObjectModel;
using ArtOfTest.WebAii.Silverlight;
using ArtOfTest.WebAii.Silverlight.UI;

using System.Net.Http;
using System.Net.Http.Formatting;

namespace TestRestAPI
{
    public class Get : BaseWebAiiTest
    {
        [CodedStep(@"GET")]
        public void Get_CodedStep()
        {
            // Close the web browser window (not needed)
            ActiveBrowser.Close();
            
            // Write action to console
            Console.WriteLine("Sending GET...");
            
            // Create and define the result of the GET. Note that GetAsync uses the BaseAddress set in the Module, "HttpClient"
            HttpResponseMessage result = RestClient.client.GetAsync("get").Result;
            
            // Handle HttpClient Result
            if ((int) result.StatusCode == 200)
            {
                // Response was OK
                Console.WriteLine("Response == 'OK'");
                
                // Write result to log
                Log.WriteLine(result.ToString());
            }
            else
            {
                // Response was not expected
                Console.WriteLine("Response != 'OK'");
                throw new Exception(result.ToString());
            }
        }
    }
}
